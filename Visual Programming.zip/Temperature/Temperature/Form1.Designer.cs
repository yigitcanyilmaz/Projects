﻿namespace Temperature
{
    partial class FrmTemp
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tempHeader = new Label();
            txtFahrenheit = new TextBox();
            txtCelsius = new TextBox();
            txtKelvin = new TextBox();
            labelFahrenheit = new Label();
            labelCelsius = new Label();
            labelKelvin = new Label();
            SuspendLayout();
            // 
            // tempHeader
            // 
            tempHeader.AutoSize = true;
            tempHeader.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            tempHeader.Location = new Point(230, 9);
            tempHeader.Name = "tempHeader";
            tempHeader.Size = new Size(264, 54);
            tempHeader.TabIndex = 0;
            tempHeader.Text = "Temperature";
            // 
            // txtFahrenheit
            // 
            txtFahrenheit.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtFahrenheit.Location = new Point(25, 220);
            txtFahrenheit.Name = "txtFahrenheit";
            txtFahrenheit.Size = new Size(180, 43);
            txtFahrenheit.TabIndex = 1;
            txtFahrenheit.TextChanged += txtFahrenheit_TextChanged_1;
            // 
            // txtCelsius
            // 
            txtCelsius.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtCelsius.Location = new Point(266, 220);
            txtCelsius.Name = "txtCelsius";
            txtCelsius.Size = new Size(190, 43);
            txtCelsius.TabIndex = 2;
            txtCelsius.TextChanged += txtCelsius_TextChanged_1;
            // 
            // txtKelvin
            // 
            txtKelvin.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtKelvin.Location = new Point(532, 220);
            txtKelvin.Name = "txtKelvin";
            txtKelvin.Size = new Size(180, 43);
            txtKelvin.TabIndex = 3;
            txtKelvin.TextChanged += txtKelvin_TextChanged_1;
            // 
            // labelFahrenheit
            // 
            labelFahrenheit.AutoSize = true;
            labelFahrenheit.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            labelFahrenheit.ForeColor = SystemColors.MenuHighlight;
            labelFahrenheit.Location = new Point(48, 266);
            labelFahrenheit.Name = "labelFahrenheit";
            labelFahrenheit.Size = new Size(123, 31);
            labelFahrenheit.TabIndex = 4;
            labelFahrenheit.Text = "Fahrenheit";
            // 
            // labelCelsius
            // 
            labelCelsius.AutoSize = true;
            labelCelsius.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            labelCelsius.ForeColor = Color.FromArgb(0, 192, 192);
            labelCelsius.Location = new Point(313, 266);
            labelCelsius.Name = "labelCelsius";
            labelCelsius.Size = new Size(85, 31);
            labelCelsius.TabIndex = 5;
            labelCelsius.Text = "Celsius";
            // 
            // labelKelvin
            // 
            labelKelvin.AutoSize = true;
            labelKelvin.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            labelKelvin.ForeColor = Color.FromArgb(128, 128, 255);
            labelKelvin.Location = new Point(588, 266);
            labelKelvin.Name = "labelKelvin";
            labelKelvin.Size = new Size(77, 31);
            labelKelvin.TabIndex = 6;
            labelKelvin.Text = "Kelvin";
            // 
            // FrmTemp
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(740, 473);
            Controls.Add(labelKelvin);
            Controls.Add(labelCelsius);
            Controls.Add(labelFahrenheit);
            Controls.Add(txtKelvin);
            Controls.Add(txtCelsius);
            Controls.Add(txtFahrenheit);
            Controls.Add(tempHeader);
            Name = "FrmTemp";
            Text = "Temperature";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label tempHeader;
        private TextBox txtFahrenheit;
        private TextBox txtCelsius;
        private TextBox txtKelvin;
        private Label labelFahrenheit;
        private Label labelCelsius;
        private Label labelKelvin;
    }
}