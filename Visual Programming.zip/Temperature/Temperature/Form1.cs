namespace Temperature
{
    public partial class FrmTemp : Form
    {
        private bool isConversionInProgress = false;
        public FrmTemp()
        {
            InitializeComponent();
        }

        private void txtFahrenheit_TextChanged_1(object sender, EventArgs e)
        {
            if (!isConversionInProgress)
            {
                if (string.IsNullOrWhiteSpace(txtFahrenheit.Text))
                {
                    txtCelsius.Clear();
                    txtKelvin.Clear();
                }
                else if (double.TryParse(txtFahrenheit.Text, out double fahrenheitValue))
                {
                    double celsiusValue = (fahrenheitValue - 32) * 5 / 9;
                    double kelvinValue = celsiusValue + 273.15;

                    txtCelsius.Text = celsiusValue.ToString();
                    txtKelvin.Text = kelvinValue.ToString();
                }
            }
        }

        private void txtCelsius_TextChanged_1(object sender, EventArgs e)
        {
            if (!isConversionInProgress)
            {
                if (string.IsNullOrWhiteSpace(txtCelsius.Text))
                {
                    txtFahrenheit.Clear();
                    txtKelvin.Clear();
                }
                else if (double.TryParse(txtCelsius.Text, out double celsiusValue))
                {
                    double fahrenheitValue = (celsiusValue * 9 / 5) + 32;
                    double kelvinValue = celsiusValue + 273.15;

                    txtFahrenheit.Text = fahrenheitValue.ToString();
                    txtKelvin.Text = kelvinValue.ToString();
                }
            }
        }

        private void txtKelvin_TextChanged_1(object sender, EventArgs e)
        {
            if (!isConversionInProgress)
            {
                if (string.IsNullOrWhiteSpace(txtKelvin.Text))
                {
                    txtFahrenheit.Clear();
                    txtCelsius.Clear();
                }
                else if (double.TryParse(txtKelvin.Text, out double kelvinValue))
                {
                    double celsiusValue = kelvinValue - 273.15;
                    double fahrenheitValue = (celsiusValue * 9 / 5) + 32;

                    txtFahrenheit.Text = fahrenheitValue.ToString();
                    txtCelsius.Text = celsiusValue.ToString();
                }
            }
        }

    }
}
