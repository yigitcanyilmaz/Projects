﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Transkript
{
    public partial class Form2 : Form
    {
        private void Form2_Click(object sender, EventArgs e)
        {
            // Form2 üzerinde bir tıklama olayı gerçekleştiğinde yapılacak işlemleri buraya ekleyin.
        }

        public int StudentNo { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public string City { get; set; }
        public string Department { get; set; }
        public Image StudentImage { get; set; }

        public Form2(int studentNo, string firstName, string lastName, int age, string city, string department, Image studentImage)
        {
            InitializeComponent();
            StudentNo = studentNo;
            FirstName = firstName;
            LastName = lastName;
            Age = age;
            City = city;
            Department = department;
            StudentImage = studentImage;
            // Set the labels and picture box with the provided student information
            SetControls();
        }

        private void SetControls()
        {
            // Set the text of labels to display the student information
            label3.Text = "Student Number: " + StudentNo;
            label1.Text = "First Name: " + FirstName;
            label2.Text = "Last Name: " + LastName;
            label4.Text = "Age: " + Age;
            label5.Text = "City: " + City;
            label6.Text = "Department: " + Department;
            // Set the picture box to display the student image
            pictureBox1.Image = StudentImage;
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage; // Adjust the image size mode as needed
        }
    }
}

