﻿

namespace Transkript
{
    internal class DetailedViewForm
    {
        private int studentNo;
        private string? firstName;
        private string? lastName;
        private int age;
        private string? city;
        private string? department;
        private Image student_image;

        public DetailedViewForm(int studentNo, string? firstName, string? lastName, int age, string? city, string? department, Image student_image)
        {
            this.studentNo = studentNo;
            this.firstName = firstName;
            this.lastName = lastName;
            this.age = age;
            this.city = city;
            this.department = department;
            this.student_image = student_image;
        }

        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}