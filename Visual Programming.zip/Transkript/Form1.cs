namespace Transkript
{
    public partial class Form1 : Form
    {
        private List<Student> students; // Declare the students list as a field of the Form1 class

        public Form1()
        {
            InitializeComponent();
            students = new List<Student>(); // Initialize the students list
                                            // Call a method to populate the DataGridView with data
            PopulateDataGridView();

            // Subscribe to the CellContentClick event
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
        }

        public class Student
        {
            public int student_no { get; set; }
            public string first_name { get; set; }
            public string last_name { get; set; }
            public int age { get; set; }
            public string city { get; set; }
            public string department { get; set; }
            public Image student_image { get; set; } // Add the Image property for the student image
        }

        private void PopulateDataGridView()
        {
            // Populate the students list with Student objects
            students.Add(new Student { student_no = 1, first_name = "Jason", last_name = "Voorhees", age = 20, city = "Springfield", department = "PHYS", student_image = Image.FromFile("path to the image") });
            students.Add(new Student { student_no = 2, first_name = "Jane", last_name = "Smith", age = 21, city = "Los Angeles", department = "IE", student_image = Image.FromFile("path to the image") });
            students.Add(new Student { student_no = 3, first_name = "Mike", last_name = "Diver", age = 22, city = "Maryland", department = "CE", student_image = Image.FromFile("path to the image") });
            students.Add(new Student { student_no = 4, first_name = "Jessica", last_name = "William", age = 19, city = "London", department = "CE", student_image = Image.FromFile("path to the image") });
            // Add more students as needed



            // Populate the DataGridView with data from the students list
            foreach (var student in students)
            {
                dataGridView1.Rows.Add(student.student_no, student.first_name, student.last_name, student.age, student.city, student.department);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == dataGridView1.Columns["Details"].Index)
            {
                int studentNo = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["StudentNo"].Value);
                string firstName = dataGridView1.Rows[e.RowIndex].Cells["FirstName"].Value != null ? dataGridView1.Rows[e.RowIndex].Cells["FirstName"].Value.ToString() : string.Empty;
                string lastName = dataGridView1.Rows[e.RowIndex].Cells["LastName"].Value != null ? dataGridView1.Rows[e.RowIndex].Cells["LastName"].Value.ToString() : string.Empty;
                int Age = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["Age"].Value);
                string City = dataGridView1.Rows[e.RowIndex].Cells["City"].Value != null ? dataGridView1.Rows[e.RowIndex].Cells["City"].Value.ToString() : string.Empty;
                string Department = dataGridView1.Rows[e.RowIndex].Cells["Department"].Value != null ? dataGridView1.Rows[e.RowIndex].Cells["Department"].Value.ToString() : string.Empty;
                // Retrieve other student information accordingly

                // Open the DetailedViewForm with the selected student's information
                Student selectedStudent = students[e.RowIndex]; // Get the selected student from the list
                DetailedViewForm detailedViewForm = new DetailedViewForm(studentNo, firstName, lastName, Age, City, Department, selectedStudent.student_image);
                detailedViewForm.Show();
            }
        }
    }
}
