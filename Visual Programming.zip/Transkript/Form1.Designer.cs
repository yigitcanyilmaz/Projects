﻿namespace Transkript
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            studentNo = new DataGridViewTextBoxColumn();
            firstName = new DataGridViewTextBoxColumn();
            lastName = new DataGridViewTextBoxColumn();
            age = new DataGridViewTextBoxColumn();
            city = new DataGridViewTextBoxColumn();
            department = new DataGridViewTextBoxColumn();
            studentImage = new DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { studentNo, firstName, lastName, age, city, department, studentImage });
            dataGridView1.Location = new Point(33, 12);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(931, 426);
            dataGridView1.TabIndex = 0;
            // 
            // studentNo
            // 
            studentNo.HeaderText = "student no";
            studentNo.MinimumWidth = 6;
            studentNo.Name = "studentNo";
            studentNo.Width = 125;
            // 
            // firstName
            // 
            firstName.HeaderText = "first name ";
            firstName.MinimumWidth = 6;
            firstName.Name = "firstName";
            firstName.Width = 125;
            // 
            // lastName
            // 
            lastName.HeaderText = "last name";
            lastName.MinimumWidth = 6;
            lastName.Name = "lastName";
            lastName.Width = 125;
            // 
            // age
            // 
            age.HeaderText = "age";
            age.MinimumWidth = 6;
            age.Name = "age";
            age.Width = 125;
            // 
            // city
            // 
            city.HeaderText = "city";
            city.MinimumWidth = 6;
            city.Name = "city";
            city.Width = 125;
            // 
            // department
            // 
            department.HeaderText = "department";
            department.MinimumWidth = 6;
            department.Name = "department";
            department.Width = 125;
            // 
            // studentImage
            // 
            studentImage.HeaderText = "details";
            studentImage.MinimumWidth = 6;
            studentImage.Name = "studentImage";
            studentImage.Width = 125;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1024, 450);
            Controls.Add(dataGridView1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn studentNo;
        private DataGridViewTextBoxColumn firstName;
        private DataGridViewTextBoxColumn lastName;
        private DataGridViewTextBoxColumn age;
        private DataGridViewTextBoxColumn city;
        private DataGridViewTextBoxColumn department;
        private DataGridViewButtonColumn studentImage;
    }
}
