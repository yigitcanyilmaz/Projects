using System;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class Form1 : Form
    {
        private Button[] buttons; // Make invisible the buttons
        private int playerTurn = 1; // 1 for player X, 2 for player O
        private bool gameOver = false;

        public Form1()
        {
            InitializeComponent();
            InitializeGame();
        }

        private void InitializeGame()
        {
            // Adding buttons to the starting
            buttons = new Button[] { btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9 };

            foreach (Button button in buttons)
            {
                button.Text = "";
                button.Enabled = true;
                button.Click += Button_Click; // Set click for every buttons
            }

            playerTurn = 1;
            gameOver = false;
            lblStatus.Text = "Player 1's turn (X)";
        }

        private void Button_Click(object sender, EventArgs e)
        {
            if (gameOver)
                return;

            Button button = (Button)sender;

            // If the button is conqured, don't make any equation
            if (button.Text != "")
                return;

            // Set for player X
            button.Text = (playerTurn % 2 == 0) ? "O" : "X";
            button.Enabled = false;

            // Check status of game
            if (CheckWin())
            {
                lblStatus.Text = "Player " + ((playerTurn % 2) + 1) + " wins!";
                gameOver = true;
            }
            else if (CheckDraw())
            {
                lblStatus.Text = "It's a draw!";
                gameOver = true;
            }
            else
            {
                playerTurn++;
                lblStatus.Text = "Player " + ((playerTurn % 2) + 1) + "'s turn (" + ((playerTurn % 2 == 0) ? "O" : "X") + ")";
            }
        }

        private bool CheckWin()
        {
            // Check the winning events

            return (btn1.Text != "" && btn1.Text == btn2.Text && btn2.Text == btn3.Text) ||
                   (btn4.Text != "" && btn4.Text == btn5.Text && btn5.Text == btn6.Text) ||
                   (btn7.Text != "" && btn7.Text == btn8.Text && btn8.Text == btn9.Text) ||
                   (btn1.Text != "" && btn1.Text == btn4.Text && btn4.Text == btn7.Text) ||
                   (btn2.Text != "" && btn2.Text == btn5.Text && btn5.Text == btn8.Text) ||
                   (btn3.Text != "" && btn3.Text == btn6.Text && btn6.Text == btn9.Text) ||
                   (btn1.Text != "" && btn1.Text == btn5.Text && btn5.Text == btn9.Text) ||
                   (btn3.Text != "" && btn3.Text == btn5.Text && btn5.Text == btn7.Text);
        }

        private bool CheckDraw()
        {
            // Check if the game is draw or not
            foreach (Button button in buttons)
            {
                if (button.Text == "")
                {
                    return false; // There's a empty box left, game is not over yet
                }
            }
            return true; // There's no empty box left, draw
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            // Restart the game
            InitializeGame();
        }
    }
}
