﻿using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace TicTacToe
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn1 = new Button();
            btn2 = new Button();
            btn3 = new Button();
            btn4 = new Button();
            btn5 = new Button();
            btn6 = new Button();
            btn7 = new Button();
            btn8 = new Button();
            btn9 = new Button();
            btnReset = new Button();
            lblStatus = new Label();
            SuspendLayout();
            // 
            // btn1
            // 
            btn1.FlatStyle = FlatStyle.Flat;
            btn1.Location = new Point(55, 23);
            btn1.Name = "btn1";
            btn1.Size = new Size(126, 113);
            btn1.TabIndex = 0;
            btn1.Text = "button1";
            btn1.UseVisualStyleBackColor = true;
            // 
            // btn2
            // 
            btn2.FlatStyle = FlatStyle.Flat;
            btn2.Location = new Point(187, 23);
            btn2.Name = "btn2";
            btn2.Size = new Size(126, 113);
            btn2.TabIndex = 1;
            btn2.Text = "button2";
            btn2.UseVisualStyleBackColor = true;
            // 
            // btn3
            // 
            btn3.FlatStyle = FlatStyle.Flat;
            btn3.Location = new Point(319, 23);
            btn3.Name = "btn3";
            btn3.Size = new Size(126, 113);
            btn3.TabIndex = 2;
            btn3.Text = "button3";
            btn3.UseVisualStyleBackColor = true;
            // 
            // btn4
            // 
            btn4.FlatStyle = FlatStyle.Flat;
            btn4.Location = new Point(55, 142);
            btn4.Name = "btn4";
            btn4.Size = new Size(126, 113);
            btn4.TabIndex = 3;
            btn4.Text = "button4";
            btn4.UseVisualStyleBackColor = true;
            // 
            // btn5
            // 
            btn5.FlatStyle = FlatStyle.Flat;
            btn5.Location = new Point(187, 142);
            btn5.Name = "btn5";
            btn5.Size = new Size(126, 113);
            btn5.TabIndex = 4;
            btn5.Text = "button5";
            btn5.UseVisualStyleBackColor = true;
            // 
            // btn6
            // 
            btn6.FlatStyle = FlatStyle.Flat;
            btn6.Location = new Point(319, 142);
            btn6.Name = "btn6";
            btn6.Size = new Size(126, 113);
            btn6.TabIndex = 5;
            btn6.Text = "button6";
            btn6.UseVisualStyleBackColor = true;
            // 
            // btn7
            // 
            btn7.FlatStyle = FlatStyle.Flat;
            btn7.Location = new Point(55, 261);
            btn7.Name = "btn7";
            btn7.Size = new Size(126, 113);
            btn7.TabIndex = 6;
            btn7.Text = "button7";
            btn7.UseVisualStyleBackColor = true;
            // 
            // btn8
            // 
            btn8.FlatStyle = FlatStyle.Flat;
            btn8.Location = new Point(187, 261);
            btn8.Name = "btn8";
            btn8.Size = new Size(126, 113);
            btn8.TabIndex = 7;
            btn8.Text = "button8";
            btn8.UseVisualStyleBackColor = true;
            // 
            // btn9
            // 
            btn9.FlatStyle = FlatStyle.Flat;
            btn9.Location = new Point(319, 261);
            btn9.Name = "btn9";
            btn9.Size = new Size(126, 113);
            btn9.TabIndex = 8;
            btn9.Text = "button9";
            btn9.UseVisualStyleBackColor = true;
            // 
            // btnReset
            // 
            btnReset.Location = new Point(560, 261);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(126, 113);
            btnReset.TabIndex = 9;
            btnReset.Text = "Reset";
            btnReset.UseVisualStyleBackColor = true;
            btnReset.Click += btnReset_Click;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblStatus.Location = new Point(598, 117);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(0, 25);
            lblStatus.TabIndex = 10;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblStatus);
            Controls.Add(btnReset);
            Controls.Add(btn9);
            Controls.Add(btn8);
            Controls.Add(btn7);
            Controls.Add(btn6);
            Controls.Add(btn5);
            Controls.Add(btn4);
            Controls.Add(btn3);
            Controls.Add(btn2);
            Controls.Add(btn1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn1;
        private Button btn2;
        private Button btn3;
        private Button btn4;
        private Button btn5;
        private Button btn6;
        private Button btn7;
        private Button btn8;
        private Button btn9;
        private Button btnReset;
        private Label lblStatus;
    }
 
}
