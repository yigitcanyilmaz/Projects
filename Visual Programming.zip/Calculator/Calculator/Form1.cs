using System;
using System.Collections.Generic;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {

        private char _equation;
        private bool _IsScreenCleared;
        private int _num1;

        public Form1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            if (_IsScreenCleared)
            {
                ScreenLabel.Text = "";
                _IsScreenCleared = false;
            }
            if (ScreenLabel.Text == "0") ScreenLabel.Text = "";
            ScreenLabel.Text += "1";
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            if (_IsScreenCleared)
            {
                ScreenLabel.Text = "";
                _IsScreenCleared = false;
            }
            if (ScreenLabel.Text == "0") ScreenLabel.Text = "";
            ScreenLabel.Text += "2";
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            if (_IsScreenCleared)
            {
                ScreenLabel.Text = "";
                _IsScreenCleared = false;
            }
            if (ScreenLabel.Text == "0") ScreenLabel.Text = "";
            ScreenLabel.Text += "3";
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            if (_IsScreenCleared)
            {
                ScreenLabel.Text = "";
                _IsScreenCleared = false;
            }
            if (ScreenLabel.Text == "0") ScreenLabel.Text = "";
            ScreenLabel.Text += "4";
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            if (_IsScreenCleared)
            {
                ScreenLabel.Text = "";
                _IsScreenCleared = false;
            }
            if (ScreenLabel.Text == "0") ScreenLabel.Text = "";
            ScreenLabel.Text += "5";
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            if (_IsScreenCleared)
            {
                ScreenLabel.Text = "";
                _IsScreenCleared = false;
            }
            if (ScreenLabel.Text == "0") ScreenLabel.Text = "";
            ScreenLabel.Text += "6";
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            if (_IsScreenCleared)
            {
                ScreenLabel.Text = "";
                _IsScreenCleared = false;
            }
            if (ScreenLabel.Text == "0") ScreenLabel.Text = "";
            ScreenLabel.Text += "7";
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            if (_IsScreenCleared)
            {
                ScreenLabel.Text = "";
                _IsScreenCleared = false;
            }
            if (ScreenLabel.Text == "0") ScreenLabel.Text = "";
            ScreenLabel.Text += "8";
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            if (_IsScreenCleared)
            {
                ScreenLabel.Text = "";
                _IsScreenCleared = false;
            }
            if (ScreenLabel.Text == "0") ScreenLabel.Text = "";
            ScreenLabel.Text += "9";
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            if (_IsScreenCleared)
            {
                ScreenLabel.Text = "";
                _IsScreenCleared = false;
            }
            if (ScreenLabel.Text == "0") ScreenLabel.Text = "";
            ScreenLabel.Text += "0";
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            _equation = '+';
            _IsScreenCleared = true;
            _num1 = Convert.ToInt32(ScreenLabel.Text);
        }

        private void btnMin_Click(object sender, EventArgs e)
        {
            _equation = '-';
            _IsScreenCleared = true;
            _num1 = Convert.ToInt32(ScreenLabel.Text);
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            _equation = '*';
            _IsScreenCleared = true;
            _num1 = Convert.ToInt32(ScreenLabel.Text);
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            _equation = '/';
            _IsScreenCleared = true;
            _num1 = Convert.ToInt32(ScreenLabel.Text);
        }

        private void btnEql_Click(object sender, EventArgs e)
        {
            int num2 = Convert.ToInt32(ScreenLabel.Text);
            int result;

            switch (_equation)
            {
                case '+':
                    result = _num1 + num2;
                    break;

                case '-':
                    result = _num1 - num2;
                    break;

                case '*':
                    result = _num1 * num2;
                    break;

                case '/':
                    result = _num1 / num2;
                    break;

                default:
                    result = 0;
                    break;
            }

            ScreenLabel.Text = Convert.ToString(result);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ScreenLabel.Text = "0";
        }
    }
}